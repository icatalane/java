package edu.uoc.trip.model.levels;

/**
 * Level difficutlty class of the game.
 * <br/>
 *
 *
 *  @author Iñigo Catalan
 *  @version 1.0
 */

public enum LevelDifficulty {

    /**
     * enumeration values
     */
    STARTER(),
    JUNIOR(),
    EXPERT(),
    MASTER(),
    WIZARD();

}
