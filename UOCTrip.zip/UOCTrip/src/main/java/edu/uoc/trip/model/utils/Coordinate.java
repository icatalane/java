package edu.uoc.trip.model.utils;

import java.util.Objects;

/**
 * Coordinate class of the game.
 * <br/>
 *
 *
 *  @author Iñigo Catalan
 *  @version 1.0
 */

public class Coordinate {

    /**
     * row of the coordinate
     */
    private int row;

    /**
     * column of the coordinate
     */
    private int column;

    /**
     * constructor
     * @param row of the coordinate
     * @param column of the coordinate
     */
    public Coordinate (int row, int column) {
        setRow (row);
        setColumn (column);
    }

    /**
     * getter of the row
     * @return row value
     */
    public int getRow() {
        return row;
    }

    /**
     * setter of the row
     * @param row value
     */
    private void setRow(int row) {
        this.row = row;
    }

    /**
     * getter of the column
     * @return column value
     */
    public int getColumn() {
        return column;
    }

    /**
     * setter of the column
     * @param column value
     */
    private void setColumn (int column) {
        this.column = column;
    }

    /**
     * checks if objects are equal
     * @param obj to compare
     * @return true after comparing equality
     */
    @Override
    public boolean equals(Object obj) {
        if (obj != null && getClass() != obj.getClass()) return false;
        Coordinate var = (Coordinate) obj;
        if (var == null) {
            return false;
        }
        return this.getRow() == var.getRow() && this.getColumn() == var.getColumn();
    }

    /**
     *
     * @return value as hashcode
     */
    @Override
    public int hashCode() {
        return Objects.hash(row, column);
    }

    /**
     *
     * @return (r,c) format
     */
    @Override
    public String toString() {
        return "(" + row + "," + column + ")";
    }





}
