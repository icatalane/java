package edu.uoc.trip.model.cells;

import edu.uoc.trip.model.levels.Direction;
import java.util.EnumSet;

/**
 * Celltype class of the game.
 * <br/>
 *
 *
 *  @author Iñigo Catalan
 *  @version 1.0
 */

public enum CellType {

    /**
     * enum values
     */
    START ('S', '^', "start.png", new boolean[]{true, false, false, false}) {public CellType next(){
        return null;
    }},
    FINISH ('F', 'v', "finish.png", new boolean[]{false, false, true, false}) {public CellType next(){
        return null;
    }},
    MOUNTAINS ('M', 'M', "mountains.png", new boolean[]{false, false, false, false}) {public CellType next() {
        return null;
    }},
    RIVER ('~', '~', "river.png", new boolean[]{false, false, false, false}) {public CellType next() {
        return null;
    }},
    FREE ('·', '·', "free.png", new boolean[]{false, false, false, false}) {public CellType next() {
        return null;
    }},
    VERTICAL ('V', '║', "road_vertical.png", new boolean[]{true, false, true, false}) {public CellType next() {
        return HORIZONTAL;
    }},
    HORIZONTAL ('H', '═', "road_horizontal.png", new boolean[]{false, true, false, true}) {public CellType next() {
        return VERTICAL;
    }},
    BOTTOM_RIGHT ('r', '╔', "road_bottom_right.png", new boolean[]{false, true, true, false }) {public CellType next() {
        return BOTTOM_LEFT;
    }},
    BOTTOM_LEFT ('l', '╗', "road_bottom_left.png", new boolean[]{false, false, true, true}) {public CellType next() {
        return TOP_LEFT;
    }},
    TOP_RIGHT ('R', '╚', "road_top_right.png", new boolean[]{true, true, false, false}) {public CellType next() {
        return BOTTOM_RIGHT;
    }},
    TOP_LEFT ('L', '╝', "road_top_left.png", new boolean[]{true, false, false, true}) {public CellType next() {
        return TOP_RIGHT;
    }},
    ROTATABLE_VERTICAL ('G', '┃', "road_rotatable_vertical.png", new boolean[]{true, false, true, false}) {public CellType next() {
        return ROTATABLE_HORIZONTAL;
    }},
    ROTATABLE_HORIZONTAL ('g', '━', "road_rotatable_horizontal.png", new boolean[]{false, true, false, true}) {public CellType next() {
        return ROTATABLE_VERTICAL;
    }
    };

    /**
     * symbol of the cell
     */
    private char fileSymbol;
    /**
     * representation as unicode symbol
     */
    private char unicodeRepresentation;
    /**
     * representation as image
     */
    private String imageSrc;
    /**
     * connections of the cell
     */
    private boolean[] connections;

    /**
     * constructor
     * @param fileSymbol symbol of the cell
     * @param unicodeRepresentation first way of representation for playing
     * @param imageSrc second way of representation for playing
     * @param connections of the celltype
     */
    CellType (char fileSymbol, char unicodeRepresentation, String imageSrc, boolean[] connections) {
        setFileSymbol(fileSymbol);
        setUnicodeRepresentation(unicodeRepresentation);
        setImageSrc(imageSrc);
        setConnections(connections);

    }

    /**
     * getter of the symbol of the cell
     * @return fileSymbol's value
     */
    public char getFileSymbol() {
        return fileSymbol;
    }

    /**
     * setter of the symbol of the cell
     * @param fileSymbol as value
     */
    private void setFileSymbol(char fileSymbol) {
        this.fileSymbol = fileSymbol;
    }

    /**
     * getter of the unicode representation
     * @return unicodeRepresentation's value
     */
    public char getUnicodeRepresentation() {
        return unicodeRepresentation;
    }

    /**
     * setter of the unicode representation
     * @param unicodeRepresentation as value
     */
    private void setUnicodeRepresentation (char unicodeRepresentation) {
        this.unicodeRepresentation = unicodeRepresentation;
    }

    /**
     * getter of the image
     * @return imageSrc as png format
     */
    public String getImageSrc() {
        return imageSrc;
    }

    /**
     * setter of the image
     * @param imageSrc as png format
     */
    private void setImageSrc(String imageSrc) {
        this.imageSrc = imageSrc;
    }

    /**
     * setter of the cell's connections
     * @param connections available
     */
    private void setConnections (boolean[] connections) {
        this.connections = connections;
    }

    /**
     * getter of the cell's available connections
     * @return var as enumset
     */
    public EnumSet<Direction> getAvailableConnections() {
        EnumSet<Direction> var = EnumSet.noneOf(Direction.class);
        for (int i = 0; i < connections.length; i++) {
            if (connections[i]) {
                var.add(Direction.values()[i]);
            }
        }
        return var;
    }

    public static CellType map2CellType(char fileSymbol) {

        return switch (fileSymbol) {
                case 'S' -> CellType.START;
                case 'F' -> CellType.FINISH;
                case 'M' -> CellType.MOUNTAINS;
                case '~' -> CellType.RIVER;
                case 'V' -> CellType.VERTICAL;
                case 'H' -> CellType.HORIZONTAL;
                case 'r' -> CellType.BOTTOM_RIGHT;
                case 'l' -> CellType.BOTTOM_LEFT;
                case 'R' -> CellType.TOP_RIGHT;
                case 'L' -> CellType.TOP_LEFT;
                case '·' -> CellType.FREE;
                case 'G' -> CellType.ROTATABLE_VERTICAL;
                case 'g' -> CellType.ROTATABLE_HORIZONTAL;
                default -> null;
        };
    }

    public CellType next() {
        return null;
    }
}
