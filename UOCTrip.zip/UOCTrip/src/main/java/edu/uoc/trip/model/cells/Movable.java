package edu.uoc.trip.model.cells;

import edu.uoc.trip.model.utils.Coordinate;

/**
 * Movable class of the game.
 * <br/>
 *
 *
 *  @author Iñigo Catalan
 *  @version 1.0
 */

public interface Movable {

    void move(Coordinate destination);

}
