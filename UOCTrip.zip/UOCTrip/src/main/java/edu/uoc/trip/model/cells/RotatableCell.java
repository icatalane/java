package edu.uoc.trip.model.cells;

/**
 * Rotatable cell class of the game.
 * <br/>
 *
 *  @author Iñigo Catalan
 *  @version 1.0
 */

public class RotatableCell extends Cell implements Rotatable {

    /**
     * constructor
     * @param row of the cell
     * @param column of the cell
     * @param cellType of the cell
     */
    public RotatableCell (int row, int column, CellType cellType) {
        super(row, column, cellType);
    }

    /**
     *
     * @return true if it is movable
     */
    @Override
    public boolean isMovable() {
        return false;
    }

    /**
     *
     * @return true if it rotable
     */
    @Override
    public boolean isRotatable() {
        return true;
    }

    /**
     * rotate
     */
    @Override
    public void rotate() {
        setType(getType().next());
    }

}
