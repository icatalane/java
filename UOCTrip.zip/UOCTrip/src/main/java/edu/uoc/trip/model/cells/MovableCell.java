package edu.uoc.trip.model.cells;

import edu.uoc.trip.model.utils.Coordinate;

/**
 * Movable cell class of the game.
 * <br/>
 *
 *  @author Iñigo Catalan
 *  @version 1.0
 */

public class MovableCell extends Cell implements Movable {

    /**
     * constructor
     * @param row of the cell
     * @param column of the cell
     * @param type of the cell
     */
    public MovableCell (int row, int column, CellType type) {
        super(row, column, type);
    }

    /**
     * boolean checker of the cell
     * @return true if it is movable
     */
    @Override
    public boolean isMovable() {
        return true;
    }

    /**
     * boolean checker of the cell
     * @return true if it is rotable
     */
    @Override
    public boolean isRotatable() {
        return false;
    }

    /**
     * move method for the cell
     * @param destination as coordinate
     */
    @Override
    public void move (Coordinate destination)  {
        setCoordinate(destination.getRow(), destination.getColumn());
    }
}
