package edu.uoc.trip.model.levels;

/**
 * Direction class of the game.
 * <br/>
 *
 *
 *  @author Iñigo Catalan
 *  @version 1.0
 */

public enum Direction {

    /**
     * enumeration values
     */
    UP(-1, 0, 2),
    RIGHT(0, 1, 3),
    DOWN(1, 0, 0),
    LEFT(0, -1, 1);

    /**
     * row of the direction
     */
    private final int dRow;
    /**
     * column of the direction
     */

    private final int dColumn;

    /**
     * opposite value of the direction
     */
    private final int opposite;

    /**
     * constructor
     * @param dRow of the direction
     * @param dColumn of the direction
     * @param opposite value of the direction
     */
    Direction (int dRow, int dColumn, int opposite){
        this.dRow = dRow;
        this.dColumn = dColumn;
        this.opposite = opposite;
    }

    /**
     * getter of the values by index
     * @param index as enumeration value
     * @return values of the index
     */
    public static Direction getValueByIndex(int index) {
        return values()[index];
    }

    /**
     * getter of the row
     * @return row of the direction
     */
    public int getDRow() {
        return dRow;
    }

    /**
     * getter of the column
     * @return column of the direction
     */
    public int getDColumn() {
        return dColumn;
    }

    /**
     * getter of the opposite
     * @return index values of the opposite
     */
    public Direction getOpposite() {
        return getValueByIndex(opposite);
    }

}
