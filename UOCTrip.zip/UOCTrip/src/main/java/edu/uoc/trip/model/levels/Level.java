package edu.uoc.trip.model.levels;

import edu.uoc.trip.model.cells.*;
import edu.uoc.trip.model.utils.Coordinate;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Objects;
import java.util.stream.Stream;

/**
 * Class that represents each level of the game.
 *
 * @author David García-Solórzano
 * @version 1.0
 */
public class Level {

    /**
     * Size of the board, i.e. size x size.
     */
    private int size;

    /**
     * Difficulty of the level
     */
    private LevelDifficulty difficulty;

    /**
     * Representation of the board.
     */
    private Cell[][] board;

    /**
     * Number of moves that the player has made so far.
     */
    private int numMoves = 0;

    /**
     * Minimum value that must be assigned to the attribute "size".
     */
    private static final int MINIMUM_BOARD_SIZE = 3;

    /**
     * Constructor
     *
     * @param fileName Name of the file that contains level's data.
     * @throws LevelException When there is any error while parsing the file.
     */
    public Level(String fileName) throws LevelException {
        setNumMoves(0);
        parse(fileName);
    }

    /**
     * Parses/Reads level's data from the given file.<br/>
     * It also checks which the board's requirements are met.
     *
     * @param fileName Name of the file that contains level's data.
     * @throws LevelException When there is any error while parsing the file
     * or some board's requirement is not satisfied.
     */
    private void parse(String fileName) throws LevelException{
        boolean isStarting = false;
        boolean isFinish = false;
        String line;

        ClassLoader classLoader = getClass().getClassLoader();
        InputStream inputStream = Objects.requireNonNull(classLoader.getResourceAsStream(fileName));

       // InputStream inputStream = Objects.requireNonNull(getClass().getResourceAsStream(fileName));

        try(InputStreamReader streamReader = new InputStreamReader(inputStream, StandardCharsets.UTF_8);
            BufferedReader reader = new BufferedReader(streamReader)){

            line = getFirstNonEmptyLine(reader);

            if (line  != null) {
                setSize(Integer.parseInt(line));
            }

            line = getFirstNonEmptyLine(reader);

            if (line != null) {
                setDifficulty(LevelDifficulty.valueOf(line));
            }

            board = new Cell[getSize()][getSize()];

            for (int row = 0; row < getSize(); row++) {
                char[] rowChar = Objects.requireNonNull(getFirstNonEmptyLine(reader)).toCharArray();
                for (int column = 0; column < getSize(); column++) {
                    board[row][column] = CellFactory.getCellInstance(row, column,
                            Objects.requireNonNull(CellType.map2CellType(rowChar[column])));
                }
            }

        }catch (IllegalArgumentException | IOException e){
            throw new LevelException(LevelException.ERROR_PARSING_LEVEL_FILE);
        }

        //Check if there is one starting cell, one finish cell and, at least, any other type of cell.
        for(var j =0; j<getSize(); j++){

            if(getCell(new Coordinate(getSize()-1,j)).getType() == CellType.START){
                isStarting = true;
            }

            if(getCell(new Coordinate(0,j)).getType() == CellType.FINISH){
                isFinish = true;
            }
        }

        //Checks if there are more than one starting cell
        if(Stream.of(board).flatMap(Arrays::stream).filter(x -> x.getType() == CellType.START).count()>1){
            throw new LevelException(LevelException.ERROR_PARSING_LEVEL_FILE);
        }

        //Checks if there are more than one finish cell
        if(Stream.of(board).flatMap(Arrays::stream).filter(x -> x.getType() == CellType.FINISH).count()>1){
            throw new LevelException(LevelException.ERROR_PARSING_LEVEL_FILE);
        }

        if(!isStarting){
            throw new LevelException(LevelException.ERROR_NO_STARTING);
        }

        if(!isFinish){
            throw new LevelException(LevelException.ERROR_NO_FINISH);
        }

        //Checks if there is one road (i.e. movable or rotatable cell) at least.
        if(Stream.of(board).flatMap(Arrays::stream).noneMatch(x -> x.isMovable() || x.isRotatable())){
            throw new LevelException(LevelException.ERROR_NO_ROAD);
        }

    }

    /**
     * This a helper method for {@link #parse(String fileName)} which returns
     * the first non-empty and non-comment line from the reader.
     *
     * @param br BufferedReader object to read from.
     * @return First line that is a parsable line, or {@code null} there are no lines to read.
     * @throws IOException if the reader fails to read a line.
     */
    private String getFirstNonEmptyLine(final BufferedReader br) throws IOException {
        do {

            String s = br.readLine();

            if (s == null) {
                return null;
            }
            if (s.isBlank() || s.startsWith("#")) {
                continue;
            }

            return s;
        } while (true);
    }

    //////////////////////////////////////////////////////////////////////////////////////////////////////////////
    ///////////////////////////////////////////// NEW ////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////

    /**
     * getter of the size
     * @return the size
     */
    public int getSize() {
        return this.size;
    }

    /**
     * setter of the size
     * @param size of the board
     * @throws LevelException if length smaller than 3
     */
    private void setSize (int size) throws LevelException{
        if (size < 3){
            throw new LevelException(LevelException.ERROR_BOARD_SIZE);
        } else {
            this.size = size;
        }
    }

    /**
     * getter of the difficulty
     * @return difficulty
     */
    public LevelDifficulty getDifficulty() {
        return this.difficulty;
    }

    /**
     * setter of the difficulty
     * @param difficulty of the game
     */
    private void setDifficulty(LevelDifficulty difficulty) {
        this.difficulty = difficulty;
    }

    /**
     * getter of the number of moves
     * @return nr of moves
     */
    public int getNumMoves() {
        return this.numMoves;
    }

    /**
     * setter of moves
     * @param numMoves of the game
     */
    private void setNumMoves(int numMoves) {
        this.numMoves = numMoves;
    }

    /**
     * validates de position
     * @param coord
     * @return true if statement is fulfilled
     * @throws LevelException if it does not correspond to a valid coordinate
     */
    private boolean validatePosition(Coordinate coord) throws LevelException {
        return coord.getColumn() >= 0 && coord.getColumn() < getSize() &&
                coord.getRow() >= 0 && coord.getRow() < getSize();
    }

    /**
     * getter of the cell
     * @param coord of the cell
     * @return row and column of the cell
     * @throws LevelException if the coord does not meet the condition
     */
    public Cell getCell(Coordinate coord)  throws LevelException{
        if(validatePosition(coord)){
            return board[coord.getRow()][coord.getColumn()];
        } else {
            throw new LevelException(LevelException.ERROR_COORDINATE);
        }
    }

    /**
     * setter of the cell
     * @param coord of the cell
     * @param cell type of cell
     * @throws LevelException if the position is not validated
     */
    private void setCell(Coordinate coord, Cell cell) throws LevelException {
        if (validatePosition(coord)) {
            board[coord.getRow()][coord.getColumn()]=cell;
        } else {
            throw new LevelException(LevelException.ERROR_COORDINATE);
        }
    }

    /**
     * cells swapper
     * @param firstCoord coords of the first cell
     * @param secondCoord coords of the second cell
     * @throws LevelException if the cell is not movable
     */
    public void swapCells(Coordinate firstCoord, Coordinate secondCoord) throws LevelException {

        Cell box1 = getCell(firstCoord);        // define aux variables
        Cell box2 = getCell(secondCoord);

        if(box1 instanceof MovableCell && box2 instanceof MovableCell) {
            MovableCell boxMov1 = (MovableCell) box1;       // define aux variables
            MovableCell boxMov2 = (MovableCell) box2;

            boxMov1.move(secondCoord);
            boxMov2.move(firstCoord);

            setCell(firstCoord, boxMov2);               //exchange values
            setCell(secondCoord, boxMov1);

            setNumMoves(getNumMoves () +1);

        } else {
            throw new LevelException(LevelException.ERROR_NO_MOVABLE_CELL);
        }
    }

    /**
     * boolen method
     * @return true in case the game is solved
     */
    public boolean isSolved() {

        int pos = 2;
        int x=0;
        int y=1;
        Direction[] positions = {Direction.UP, Direction.RIGHT, Direction.DOWN, Direction.LEFT};

        for (int i=0; i<board[0].length ;i++){
            if (board[0][i].getType() == CellType.FINISH ){
                x = i;
                break;
            }
        }

        while (board[y][x].getType() != CellType.START){
            for(int i=0; i<2; i++) {
                pos++;
                if (pos >3){
                    pos =0;
                }
            }
            if (!board[y][x].getType().getAvailableConnections().contains(positions[pos])){
                return false;
            }

            for (int i=0; i<3; i++) {
                pos++;
                if (pos >3){
                    pos =0;
                }

                if(board[y][x].getType().getAvailableConnections().contains(positions[pos])){
                    break;
                }
            }

            if(pos== 0) {
                y--;
            } else if (pos==1) {
                x++;
            }else if (pos==2) {
                y++;
            }else if (pos == 3) {
                x--;
            }

            if (x >= board[1].length || y >= board[0].length || x<0 || y<0 || (x==0 && y==1)){
                return false;
            }
        }

        return positions[pos] == Direction.DOWN;

    }


    @Override
    public String toString() {
        String boardAux = "";
        int ASCIIcode = 97;         // not checkstyle compliant but better name to understand
        for (int i=1; i<board[1].length+1; i++){
            boardAux = boardAux + "" + i;
        }

        for (int i=0; i<board[0].length; i++){
            //boardAux = boardAux + "\n" + Character.toString(ASCIIcode +i) + "|";        // error did appear at "\n"
            boardAux = boardAux + System.lineSeparator() + Character.toString(ASCIIcode +i) + "|";
            for (int j=0; j<board[1].length; j++){
                boardAux = boardAux + board[i][j].getType().getUnicodeRepresentation() ;
            }
        }
        return boardAux;
    }

    /**
     * method to rotate the cell
     * @param coord of the cell to rotate
     * @throws LevelException if the cell is not rotable
     */
    public void rotateCell (Coordinate coord) throws LevelException {
        if (board[coord.getRow()][coord.getColumn()].isRotatable()){
            ((RotatableCell)board[coord.getRow()][coord.getColumn()]).rotate();
            numMoves++;
        } else {
            throw new LevelException(LevelException.ERROR_NO_ROTATABLE_CELL);
        }
    }
}
