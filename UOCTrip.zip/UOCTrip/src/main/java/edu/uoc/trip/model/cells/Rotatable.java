package edu.uoc.trip.model.cells;

/**
 * Rotatable class of the game.
 * <br/>
 *
 *
 *  @author Iñigo Catalan
 *  @version 1.0
 */

public interface Rotatable {

    void rotate();
}
