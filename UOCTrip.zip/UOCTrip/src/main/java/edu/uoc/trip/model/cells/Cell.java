package edu.uoc.trip.model.cells;

import edu.uoc.trip.model.utils.Coordinate;

/**
 * Cell class of the game.
 * <br/>
 *
 *
 *  @author Iñigo Catalan
 *  @version 1.0
 */

public class Cell {
    /**
     * type of the cell
     */
    private CellType type;

    /**
     * coordinates associated to the cell
     */
    private Coordinate coordinate;

    /**
     * constructor
     * @param row first coordinate of the cell
     * @param column second coordinate of the cell
     * @param type third coordinate of the cell, type of cell
     */
    public Cell (int row, int column, CellType type) {
        setType(type);
        setCoordinate(row, column);
    }

    /**
     * getter of the type of the cell
     * @return the type of the cell
     */
    public CellType getType() {
        return this.type;
    }

    /**
     * setter of the type of the cell
     * @param type
     */
    protected void setType(CellType type){
        this.type = type;
    }

    /**
     * getter of the coordinates
     * @return
     */
    public Coordinate getCoordinate() {
        return this.coordinate;
    }

    /**
     * setter of the coordinates
     * @param row
     * @param column
     */
    protected void setCoordinate(int row, int column) {
        this.coordinate = new Coordinate(row, column);
    }

    /**
     * checks if the cell is movable
     * @return false if it is not
     */
    public boolean isMovable() {
        return false;
    }

    /**
     * checks if the cell is rotable
     * @return false if it is not
     */
    public boolean isRotatable() {
        return false;
    }

    /**
     * method as response of the desired information
     * @return
     */
    public String toString() {
        return String.valueOf(type.getUnicodeRepresentation());
    }

}
